import structlog
from redis import Redis
from shared.telemetry import get_tracer, init_telemetry, setup_logging
from shared.utils import IdempotencyMiddleware
from shared.worker import Worker

SERVICE_NAME = "identity-worker"
setup_logging(SERVICE_NAME)
init_telemetry(SERVICE_NAME)
logger = structlog.get_logger(__name__)
tracer = get_tracer()

redis_client = Redis(host="redis", port=6379, db=0)
idempotency = IdempotencyMiddleware(redis_client)


def handle_create_user(payload: dict):
    user = payload.get("user")
    idem_key = payload.get("idempotency_key")

    if not idempotency.check_and_set(idem_key):
        logger.info("Skipping duplicate user creation", idempotency_key=idem_key)
        return

    logger.info("Creating user", user=user)


if __name__ == "__main__":
    worker = Worker(
        redis_client=redis_client,
        stream_name="jobs:identity",
        consumer_name="identity-worker-1",
    )
    worker.register_handler("create_user", handle_create_user)

    logger.info("Identity Worker started")
    worker.run()
