// ---------------------------------------------------------------------------
// Job types
// ---------------------------------------------------------------------------
export interface EnqueueResponse {
  status: string;
  job_id: string;
}

export interface JobStatusResponse {
  job_id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'unknown' | 'published' | 'scheduled' | 'draft';
  result?: string | null;
}

// ---------------------------------------------------------------------------
// Account types
// ---------------------------------------------------------------------------
export interface Account {
  id: string;
  provider: 'facebook' | 'instagram' | 'twitter' | 'linkedin' | 'threads' | string;
  name: string;
  page_id: string;
  status: 'connected' | 'expired' | 'processing';
  connected_at: string;
}

export interface ConnectAccountRequest {
  provider: string;
  name: string;
  page_id: string;
  access_token: string;
}

// ---------------------------------------------------------------------------
// Post types
// ---------------------------------------------------------------------------
export type PostStatus =
  | 'published'
  | 'scheduled'
  | 'draft'
  | 'failed'
  | 'pending'
  | 'processing'
  | 'completed';

export type PostType = 'text' | 'image' | 'video';

export interface Post {
  id: string;
  job_id?: string;
  page_id?: string;
  provider?: string;
  message?: string;
  media_url?: string;
  title?: string;
  content?: string;
  platforms?: string[];
  status: PostStatus;
  type?: PostType;
  date?: string;
  reach?: string;
  engagement?: string;
  created_at?: string;
}

// ---------------------------------------------------------------------------
// Publish types
// ---------------------------------------------------------------------------
export interface PublishPostRequest {
  page_id: string;
  provider: string;
  message: string;
  media_url?: string;
  platforms?: string[];
  idempotency_key?: string;
}

// ---------------------------------------------------------------------------
// Identity / User types
// ---------------------------------------------------------------------------
export interface User {
  id: string | number;
  name: string;
  email: string;
  avatar?: string;
}

// ---------------------------------------------------------------------------
// DLQ types
// ---------------------------------------------------------------------------
export interface DlqJob {
  message_id: string;
  payload: string;
  error: string;
  retry_count: string;
}

export interface DlqResponse {
  dlq_jobs: DlqJob[];
}
